<footer class="footer">
    <div class="container p-4">
        <div class="footer_bottom" style="margin-top: -30px">
            <div class="container text-center mt-2" style="margin-bottom: -40px">
                <p> © 2024 Developed by <a href="<?php echo e(env('GITHUB ')); ?>" style="color: #1c45ef;">Maroof
                        Sultan</a> Under the Supervision of<br><a style="color: #1c45ef;" href="<?php echo e(env('GITHUB')); ?>">Mr.
                        Muhammad Jamil</a>
                </p>
            </div>
        </div>
    </div>
</footer>
</div>
</div>
</div>
<script src="<?php echo e(url('backend/vendors/js/vendor.bundle.base.js')); ?>"></script>
<script src="<?php echo e(url('backend/vendors/js/vendor.bundle.addons.js')); ?>"></script>
<script src="<?php echo e(url('backend/js/shared/off-canvas.js')); ?>"></script>
<script src="<?php echo e(url('backend/js/shared/misc.js')); ?>"></script>
<script src="<?php echo e(url('backend/js/demo_1/dashboard.j')); ?>s"></script>
</body>

</html>
<?php /**PATH C:\Users\Maroof Sultan\Desktop\Laravel_EDUCATION\edu\resources\views/backend/layouts/footer.blade.php ENDPATH**/ ?>