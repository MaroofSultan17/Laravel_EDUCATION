<?php $__env->startSection('title', 'Contact'); ?>
<?php $__env->startSection('main-container'); ?>
    <main class="page_content">
        <section class="page_banner decoration_wrap">
            <div class="container">
                <h1 class="page_heading">Contact Us</h1>
                <ul class="breadcrumb_nav unordered_list_center">
                    <li><a href='<?php echo e(url('/')); ?>'>Home</a></li>
                    <li>Contact Us</li>
                </ul>
            </div>
            <div class="deco_item deco_img_1" data-parallax='{"y" : -200, "smoothness": 6}'>
                <img src="<?php echo e(url('frontend/images/shapes/line_shape_1.png')); ?>" alt="Line Shape Image">
            </div>
            <div class="deco_item deco_img_2" data-parallax='{"y" : 200, "smoothness": 6}'>
                <img src="<?php echo e(url('frontend/images/shapes/dot_shape_2.png')); ?>" alt="Line Shape Image">
            </div>
        </section>
        <section class="contact_section section_space_lg pt-0">
            <div class="container">
                <div class="section_space_lg pt-0">
                    <div class="row justify-content-center">
                        <div class="col col-lg-4">
                            <div class="contact_info_box"
                                style="background-image: url('frontend/images/shapes/dot_shape_3.png');">
                                <div class="inner_wrap tilt">
                                    <div class="item_icon">
                                        <img src="frontend/images/icons/icon_support.png" alt="Icon Support">
                                    </div>
                                    <div class="item_content">
                                        <h3 class="item_title">Our Telephone</h3>
                                        <ul class="icon_list unordered_list_block">
                                            <li><a
                                                    href="tel:<?php echo e(constant('sitecontact')); ?>"><?php echo e(constant('sitecontact')); ?></a>
                                            </li>
                                            <li><a
                                                    href="tel:<?php echo e(constant('sitecontact')); ?>"><?php echo e(constant('sitecontact')); ?></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col col-lg-4">
                            <div class="contact_info_box"
                                style="background-image: url('frontend/images/shapes/dot_shape_3.png');">
                                <div class="inner_wrap tilt">
                                    <div class="item_icon">
                                        <img src="frontend/images/icons/icon_email.png" alt="Icon Email">
                                    </div>
                                    <div class="item_content">
                                        <h3 class="item_title">Send us mail</h3>
                                        <ul class="icon_list unordered_list_block">
                                            <li><a href="mailto:<?php echo e(constant('siteemail')); ?>"><?php echo e(constant('siteemail')); ?></a>
                                            </li>
                                            <li><a
                                                    href="mailto:<?php echo e(constant('siteemail')); ?>"><?php echo e(constant('siteemail')); ?></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col col-lg-4">
                            <div class="contact_info_box"
                                style="background-image: url('frontend/images/shapes/dot_shape_3.png');">
                                <div class="inner_wrap tilt">
                                    <div class="item_icon">
                                        <img src="frontend/images/icons/icon_support.png" alt="Icon Support">
                                    </div>
                                    <div class="item_content">
                                        <h3 class="item_title">Address</h3>
                                        <ul class="icon_list unordered_list_block">
                                            <li><?php echo e(constant('siteaddres')); ?></li>
                                            <li><?php echo e(constant('siteaddres')); ?></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col col-lg-9">
                        <div class="contact_form_wrapper">
                            <h2 class="contact_title text-center">Have a quetions?</h2>
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-block p-4 border-left-warning"
                                    style="background-color:#3a10e5; opacity:1">
                                    <strong>
                                        <h1 style="color:#ffffff"><?php echo e($message); ?></h1>
                                    </strong>
                                </div>
                            <?php endif; ?>
                            <form action="<?php echo e(route('contact.add')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col col-md-6">
                                        <div class="form_item m-0">
                                            <input type="text" name="name" placeholder="Your Full Name"
                                                value="<?php echo e(old('name')); ?>">
                                            <?php if($errors->has('name')): ?>
                                                <span class="text-danger">
                                                    <?php echo e($errors->first('name')); ?>

                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col col-md-6">
                                        <div class="form_item m-0">
                                            <input type="email" name="email" placeholder="Your Email"
                                                value="<?php echo e(old('email')); ?>">
                                            <?php if($errors->has('email')): ?>
                                                <span class="text-danger">
                                                    <?php echo e($errors->first('email')); ?>

                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col col-md-6">
                                        <div class="form_item m-0">
                                            <input type="tel" name="phone" placeholder="Phone Number"
                                                value="<?php echo e(old('phone')); ?>">
                                            <?php if($errors->has('phone')): ?>
                                                <span class="text-danger">
                                                    <?php echo e($errors->first('phone')); ?>

                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col col-md-6">
                                        <div class="form_item m-0">
                                            <input type="text" name="subject" placeholder="Suject"
                                                value="<?php echo e(old('subject')); ?>">
                                            <?php if($errors->has('subject')): ?>
                                                <span class="text-danger">
                                                    <?php echo e($errors->first('subject')); ?>

                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form_item">
                                            <textarea name="message" placeholder="Write A Massage"><?php echo e(old('message')); ?></textarea>
                                            <?php if($errors->has('message')): ?>
                                                <span class="text-danger">
                                                    <?php echo e($errors->first('message')); ?>

                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn btn_primary" name="submit">
                                                <span>
                                                    <small>Send Message</small>
                                                    <small>Send Message</small>
                                                </span>
                                                <i class="fal fa-paper-plane ms-2"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="getstart_section decoration_wrap text-center">
            <div class="container">
                <h2 class="title_text">Ready to kick-start your career?</h2>
                <a class="btn btn_primary" href="#!">
                    <span>
                        <small>Try It For Free</small>
                        <small>Try It For Free</small>
                    </span>
                    <i class="far fa-angle-double-right ms-1"></i>
                </a>
            </div>
            <div class="deco_item deco_img_1" data-parallax='{"y" : -130, "smoothness": 6}'>
                <img src="frontend/images/shapes/line_shape_4.png" alt="Shape Image">
            </div>
            <div class="deco_item deco_img_2" data-parallax='{"y" : 130, "smoothness": 6}'>
                <img src="frontend/images/shapes/shape_5.png" alt="Shape Image">
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maroof Sultan\Desktop\Laravel_EDUCATION\edu\resources\views/frontend/contact.blade.php ENDPATH**/ ?>