<?php $__env->startSection('title', 'Catageory'); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="d-grid gap-2 d-md-flex justify-content-md-end mb-4">
                <a href="<?php echo e(url('/admin/courses/catageory/add')); ?>">
                    <button class="btn me-md-2 w-20 h-100 rounded" style="background: #1c45ef; color: white;"
                        type="button">Add
                        Catageory</button>
                </a>
            </div>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-block p-4 border-left-warning text-center mb-4"
                    style="background-color:#3a10e5; opacity:1">
                    <strong>
                        <h1 style="color:#ffffff"><?php echo e($message); ?></h1>
                    </strong>
                </div>
            <?php endif; ?>
            <div class="container-fluid mt-4 mb-3">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">catageory</th>
                            <th scope="col">catageory Details</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $catageory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courses_catageory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($courses_catageory->catageory_id); ?></th>
                                <td><?php echo e($courses_catageory->catageory_name); ?></td>
                                <td><?php echo e($courses_catageory->catageory_details); ?></td>
                                <td>
                                    <a href="#"><button class="btn"
                                            style="background: #dc2e3f; color: white;">Delete</button></a>
                                    <button class="btn" style="background: #1c45ef; color: white;">Edit</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maroof Sultan\Desktop\Laravel_EDUCATION\edu\resources\views\backend\course-catageory.blade.php ENDPATH**/ ?>