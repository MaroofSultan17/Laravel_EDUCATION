<?php $__env->startSection('title', 'Add Events'); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="d-grid gap-2 d-md-flex justify-content-md-start mb-4">
                <a href="<?php echo e(url('/admin/events')); ?>">
                    <button class="btn me-md-2 w-20 h-100 rounded" style="background: #1c45ef; color: white;"
                        type="button">Show
                        Events</button>
                </a>
            </div>
            <form class="forms-sample" method="POST" action="<?php echo e(url('/admin/events/add')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" class="form-control form-control-lg" id="title" name="title"
                        placeholder="Title" value="<?php echo e(old('title')); ?>">
                    <?php if($errors->has('title')): ?>
                        <span class="text-danger">
                            <?php echo e($errors->first('title')); ?>

                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="date">Title</label>
                    <input type="date" class="form-control form-control-lg" id="date" name="date"
                        placeholder="Date" value="<?php echo e(old('date')); ?>">
                    <?php if($errors->has('date')): ?>
                        <span class="text-danger">
                            <?php echo e($errors->first('date')); ?>

                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="address">Location</label>
                    <input type="text" class="form-control form-control-lg" id="address" name="address"
                        placeholder="Location" value="<?php echo e(old('address')); ?>">
                    <?php if($errors->has('address')): ?>
                        <span class="text-danger">
                            <?php echo e($errors->first('address')); ?>

                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label>Upload Image</label>
                    <div class="input-group ">
                        <input type="file" class="form-control form-control-lg file-upload-browse" id="image"
                            name="image" value="<?php echo e(old('image')); ?>" accept=".png,.jpeg,.jpg">
                        <?php if($errors->has('image')): ?>
                            <span class="text-danger">
                                <?php echo e($errors->first('image')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="submit" class="btn btn-success w-20 mb-3 form-control-lg rounded"
                        style="font-size: 18px;" name="submit">Submit</button>
                </div>
            </form>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maroof Sultan\Desktop\Laravel_EDUCATION\edu\resources\views\backend\events-add.blade.php ENDPATH**/ ?>