<?php $__env->startSection('title', 'Profile-Edit'); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="main-panel">
        <div class="container-fluid m-2">
            <div class="d-grid gap-2 d-md-flex justify-content-md-start mb-3">
                <a href="<?php echo e(route('profile.show', ['token' => $profiledata->token])); ?>">
                    <button class="btn me-md-2 w-20 h-100 rounded" style="background: #1C45EF; color: white;"
                        type="button">Show Profile</button>
                </a>
            </div>
            <form action="<?php echo e(route('profile_edit.submit', ['token' => $profiledata->token])); ?>" method="POST"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-floating mb-3">
                    <label for="name">Full Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Full Name"
                        value="<?php echo e($profiledata->name); ?>">
                    <?php if($errors->has('name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-floating mb-3">
                    <label for="phoneno">Phone Number</label>
                    <input type="text" class="form-control" id="phoneno" placeholder="phoneno" name="phoneno"
                        value="<?php echo e($profiledata->phoneno); ?>">
                    <?php if($errors->has('phoneno')): ?>
                        <span class="text-danger"><?php echo e($errors->first('phoneno')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-floating mb-3">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" placeholder="email" name="email"
                        value="<?php echo e($profiledata->email); ?>">
                    <?php if($errors->has('email')): ?>
                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-floating mb-3">
                    <label for="address">Address</label>
                    <input type="text" class="form-control" id="address" placeholder="address" name="address"
                        value="<?php echo e($profiledata->address); ?>">
                    <?php if($errors->has('address')): ?>
                        <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label>Upload Image</label>
                    <div class="input-group mt-2">
                        <input type="file" class="form-control  file-upload-browse" id="image" name="image"
                            accept=".png,.jpg,,.jpeg" value="<?php echo e($profiledata->image); ?>">
                        <?php if($errors->has('image')): ?>
                            <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="d-md-flex justify-content-md-end">
                    <button type="submit" class="btn btn-success w-20 mb-3  rounded"
                        style="font-size: 18px;">Submit</button>
                </div>
            </form>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maroof Sultan\Desktop\Laravel_EDUCATION\edu\resources\views\backend\profile-edit.blade.php ENDPATH**/ ?>