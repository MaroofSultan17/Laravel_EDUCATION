<?php $__env->startSection('title', 'Add Instructor'); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="d-grid gap-2 d-md-flex justify-content-md-start mb-4">
                <a href="<?php echo e(url('/admin/instructor')); ?>">
                    <button class="btn me-md-2 w-20 h-100 rounded" style="background: #1c45ef; color: white;"
                        type="button">Instructor List</button>
                </a>
            </div>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-block p-4 border-left-warning text-center"
                    style="background-color:#3a10e5; opacity:1">
                    <strong>
                        <h1 style="color:#ffffff"><?php echo e($message); ?></h1>
                    </strong>
                </div>
            <?php endif; ?>
            <form class="forms-sample" method="POST" action="<?php echo e(url('/admin/instructor/add')); ?>"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="instructor_name">Full Name</label>
                    <input type="text" class="form-control form-control-lg" id="instructor_name" name="instructor_name"
                        placeholder="Instructor Name" value="<?php echo e(old('instructor_name')); ?>">
                    <?php if($errors->has('instructor_name')): ?>
                        <span class="text-danger">
                            <?php echo e($errors->first('instructor_name')); ?>

                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="instructor_email">Email</label>
                    <input type="email" class="form-control form-control-lg" id="instructor_email"
                        placeholder="abc@gmail.com" name="instructor_email" value="<?php echo e(old('instructor_email')); ?>">
                    <?php if($errors->has('instructor_email')): ?>
                        <span class="text-danger">
                            <?php echo e($errors->first('instructor_email')); ?>

                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="instructor_contact">Contact</label>
                    <input type="text" class="form-control form-control-lg" id="instructor_contact"
                        placeholder="03090742546" name="instructor_contact" value="<?php echo e(old('instructor_contact')); ?>">
                    <?php if($errors->has('instructor_contact')): ?>
                        <span class="text-danger">
                            <?php echo e($errors->first('instructor_contact')); ?>

                        </span>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="instructor_experties">Experties</label>
                    <textarea class="form-control" id="instructor_experties" rows="2" name="instructor_experties"></textarea>
                    <?php if($errors->has('instructor_experties')): ?>
                        <span class="text-danger">
                            <?php echo e($errors->first('instructor_experties')); ?>

                        </span>
                    <?php endif; ?>
                </div>
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="submit" class="btn btn-success w-20 mb-3 form-control-lg rounded"
                        style="font-size: 18px;" name="submit">Submit</button>
                </div>
            </form>

        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Maroof Sultan\Desktop\Laravel_EDUCATION\edu\resources\views\backend\instructor-add.blade.php ENDPATH**/ ?>