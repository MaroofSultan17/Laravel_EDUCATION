<?php
define('siteemail', 'maroofsultan17@gmail.com');
define('sitecontact', '+92-309-074-2546');
define('siteaddres', 'Sahiwal, Punjab Pakistan');
define('sitefacebook', 'https://www.facebook.com/');
define('sitetwitter', 'https://twitter.com/');
define('sitelinkedin', 'https://www.linkedin.com/');
define('siteyoutube', 'https://www.youtube.com/');
